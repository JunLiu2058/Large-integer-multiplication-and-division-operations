#include<gmp.h>
#include<gmpxx.h>
#include<stdlib.h>
#include<stdio.h>

int main()
{
	FILE* f;
	f = fopen("pq.txt","a");
	mpz_t n, a, b, c, d,q,g,h,r,w;
	mpz_init_set_str(n, "21846172424281341904598427707936757940246635200372372388025959021422318611300242548196976803917996071032386603078877441208012044412077347240388502868575464720299565413024881636443479286740190337379671442722502411766451290159222199579960254444736306985457724926892993097949558057284425975444160148668948551366317113186316342856392078334027242823472342457388944869695163946460817499493095971736204561614930741619636234649445052985633160324869050427461071223770910750176627597733082717892326413386316494322367132594994215518873708290864397224377671738862975985904176969769374113127728506140647037636931134082092595967823", 10);
	mpz_init_set_str(a, "2", 10);
	mpz_init_set_str(b, "2", 10);
	mpz_init(c);
	mpz_init(d);
	mpz_init(q);
	mpz_init(r);
	mpz_init(w);
	mpz_init(h);
	mpz_sqrt(r, n);
	//mpz_add_ui(a,n,1);
	gmp_printf("���鷶Χ��2-%Zd\n",r);
	gmp_printf("�����뷶Χ\n");
	//gmp_scanf("%Zd %Zd",a,d);
	 gmp_scanf("%Zd", a);
	//mpz_set(i,a);
	mpz_nextprime(a, a);
	//while (mpz_cmp(d,a)>= 0)
	while(1)
	{ 
		mpz_mod(c, n, a);
		
		if (mpz_get_ui(c) == 0 && mpz_probab_prime_p(a, 25) > 0)
		{
			//gmp_printf("����PΪ��%Zd\n", a);
			
			{   
				
				mpz_cdiv_q(q, n, a);
				mpz_mul(h,a,q);//�˷�����
				if (mpz_cmp(h,n)==0) //�˻��Ƚ�
				{
					gmp_printf("��������a��%Zd\n", a);
					gmp_printf("����ϵ��b��%Zd\n", q);
					gmp_fprintf(f, "����aΪ:%Zd\n����bΪ:%Zd\n", a, q);
					break;
				}
				else
				{
					mpz_add(a, a, b);
					continue;
				}
				
			}
		
			
				
		}
		else
		{
			mpz_add(a, a, b);
			continue;
		}
		
		}
	mpz_clear(n);
	mpz_clear(a);
	mpz_clear(b);
	mpz_clear(c);
	mpz_clear(d);
	mpz_clear(q);
	mpz_clear(r);
	mpz_clear(w);
	mpz_clear(h);
	fclose(f);
	system("pause");
	return 0;
}